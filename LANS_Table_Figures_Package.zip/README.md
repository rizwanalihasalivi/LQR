# Figures for Tables 10 and 11

These figures reproduce the displayed values in the manuscript. No new experiments or reconstructed sample distributions are represented.

## Figure 5 — Table 10: prepared-state decision timing

Panel (a) compares mean decision time. LANS averages 0.895 ms, compared with 0.608 ms for MPC: approximately 47.2% higher in this measured scope. LQR and LQR plus feedforward average 0.029 and 0.030 ms. Disabling the residual reduces the measured stack mean to 0.524 ms; reward-on and reward-off means are close at 0.891 and 0.901 ms.

Panel (b) displays the reported p95, p99 and observed maximum for each method. LANS has p95 = 1.819 ms, p99 = 3.975 ms and an observed maximum of 8.431 ms. The separation between mean and upper-tail summaries shows why average execution time alone does not characterize timing variability. There are 2700 samples per method after warm-up. These are prepared-state decision measurements, excluding the separately measured frontend, simulator stepping, I/O and injected waiting. Neither the observed maximum nor the sum of separately timed maxima is a verified full-controller WCET bound.

Suggested caption: **Fig. 5.** Windows prepared-state decision timing from Table 10: (a) mean time and (b) p95, p99 and finite-sample maximum. Each method has 2700 samples after warm-up. The timed scope excludes the separately measured frontend, simulator stepping, I/O and injected waiting. Observed maxima are not verified WCET bounds.

## Figure 6 — Table 11: CPU-package power and energy

The three panels show mean CPU-package power, total energy per workload, and idle-adjusted energy. LANS records 8.345 W and 751.05 J, compared with MPC's 6.180 W and 556.22 J. Thus, this pilot does not demonstrate an energy advantage for LANS. The residual-disabled stack records 7.281 W and 655.35 J. Mean idle-adjusted energy is 298.97 J for LANS, 48.58 J for MPC and 50.33 J with the residual disabled.

Whiskers show ±1 sample standard deviation across three approximately 90 s workloads per method. They are not confidence intervals, standard errors or minimum–maximum ranges. The large variation, telemetry sampling gaps, varying nearby idle power and unequal workload histories limit the comparison. CPU-package telemetry does not cover the whole laptop or vehicle, and these summaries alone do not establish statistical significance or controller-only energy costs. A mean-minus-SD whisker may fall below zero for idle-adjusted energy; this does not imply an observed negative total-energy workload.

Suggested caption: **Fig. 6.** Windows CPU-package telemetry from Table 11: (a) power, (b) total energy and (c) idle-adjusted energy. Bars show means and whiskers show ±1 sample SD across three approximately 90 s workloads per method. SD describes between-workload variation, not a confidence interval or observed range. The idle-adjusted lower SD whisker may extend below zero.

## Table formatting

All 11 tables use centered captions, bold table numbers, thick top and bottom rules, a thin header rule, white cells and no vertical or body-row gridlines, following the supplied reference image. All original table cell text and numeric values are retained.

- Single-column tables: 2, 3, 5, 8, 9, 10 and 11.
- Tables spanning both columns: 1, 4, 6 and 7.

Figures 5 and 6 span both columns. The revised clean manuscript is 13 pages. The separate tracked Word copy is a native content redline against the original submitted manuscript; it uses one column for review and retains historical deletions. Use the clean Word/PDF to review the final publication layout.

## Files and reproduction

The package includes 600 dpi PNG images, vector PDF/SVG figures, the exact plotted table data as CSV, this explanation and the plotting source. CSV values are rounded manuscript summaries, not raw sample logs.

To regenerate the figures, install Python packages `numpy`, `matplotlib`, and `python-docx`, then run `python figures.py` from the extracted package. The script reads `source/LANS0605_Before_Table_Revision.docx` and writes to `outputs/`. The full revision evidence archive retains the earlier raw records and supplementary sources.
